Current status:
- Geolocation works
- Drawing polyline with watchPosition works
- Scoreboard shows previous and best score 

Future improvements:
- Better UI
- Snappier button disappearing
- Scoreboard saving between sessions
- Snap-to-road function
- Clear the old line (I couldn't get it to clear)